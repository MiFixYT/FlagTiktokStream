package com.frozav.flaglive;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText username;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(Color.rgb(10, 10, 15));
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(34), dp(22), dp(20));
        page.setBackgroundColor(Color.rgb(10, 10, 15));

        TextView title = text("FLAGLIVE", 30, Color.WHITE, true);
        page.addView(title);
        TextView subtitle = text("Угадай флаг вместе с чатом TikTok LIVE", 14, 0xFF9AA0AA, false);
        page.addView(subtitle);

        username = new EditText(this);
        username.setSingleLine(true);
        username.setHint("@ник_стримера");
        username.setHintTextColor(0xFF7C818B);
        username.setTextColor(Color.WHITE);
        username.setPadding(dp(14), 0, dp(14), 0);
        username.setBackgroundColor(0xFF1A1C24);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(52));
        inputParams.topMargin = dp(28);
        page.addView(username, inputParams);

        Button start = button("ПОДКЛЮЧИТЬСЯ И ЗАПУСТИТЬ");
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(52));
        buttonParams.topMargin = dp(14);
        page.addView(start, buttonParams);

        Button stop = button("ОСТАНОВИТЬ ИГРУ");
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, dp(48));
        stopParams.topMargin = dp(10);
        page.addView(stop, stopParams);

        status = text("Готово к подключению", 14, 0xFF55E6B0, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(20);
        page.addView(status, statusParams);

        TextView note = text(
                "Как играть:\\n1. Введи ник ведущего публичного LIVE.\\n" +
                "2. Разреши отображение поверх других приложений.\\n" +
                "3. Перейди в TikTok LIVE — игровой блок будет поверх экрана.\\n\\n" +
                "Зрители пишут название страны в чат. За первый правильный ответ игрок получает 1 очко.",
                14, 0xFFB7BBC4, false);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = dp(24);
        page.addView(note, noteParams);

        setContentView(page);

        start.setOnClickListener(v -> {
            String name = username.getText().toString().trim().replace("@", "");
            if (name.isEmpty()) {
                status.setText("Введи TikTok-ник стримера");
                return;
            }
            if (!Settings.canDrawOverlays(this)) {
                status.setText("Разреши отображение поверх других приложений");
                Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(permission);
                return;
            }
            Intent service = new Intent(this, FlagOverlayService.class);
            service.putExtra("username", name);
            startService(service);
            status.setText("Запуск подключения к @" + name + "…");
        });

        stop.setOnClickListener(v -> {
            stopService(new Intent(this, FlagOverlayService.class));
            status.setText("Игра остановлена");
        });
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.BLACK);
        b.setTextSize(13);
        b.setTypeface(null, 1);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF55E6B0));
        return b;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
}

package com.frozav.flaglive;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import io.github.jwdeveloper.tiktok.TikTokLive;

import java.text.Normalizer;
import java.util.*;

public class FlagOverlayService extends Service {
    private WindowManager windowManager;
    private LinearLayout panel;
    private TextView flagView, answerView, statusView, scoreView;
    private Object liveClient;
    private final Map<String, Integer> scores = new LinkedHashMap<>();
    private final Set<String> winnersThisRound = new HashSet<>();
    private int roundIndex = -1;

    private static class Country {
        final String flag, answer;
        final String[] aliases;
        Country(String f, String a, String... x) { flag=f; answer=a; aliases=x; }
    }

    private final List<Country> countries = Arrays.asList(
        new Country("🇳🇱", "НИДЕРЛАНДЫ", "нидерланды", "голландия", "нидерланд"),
        new Country("🇫🇷", "ФРАНЦИЯ", "франция"),
        new Country("🇩🇪", "ГЕРМАНИЯ", "германия"),
        new Country("🇯🇵", "ЯПОНИЯ", "япония"),
        new Country("🇧🇷", "БРАЗИЛИЯ", "бразилия"),
        new Country("🇮🇹", "ИТАЛИЯ", "италия"),
        new Country("🇨🇦", "КАНАДА", "канада"),
        new Country("🇺🇸", "США", "сша", "соединенные штаты", "соединённые штаты", "америка"),
        new Country("🇪🇸", "ИСПАНИЯ", "испании", "испания"),
        new Country("🇬🇧", "ВЕЛИКОБРИТАНИЯ", "великобритания", "британия", "англия"),
        new Country("🇺🇦", "УКРАИНА", "украина"),
        new Country("🇰🇿", "КАЗАХСТАН", "казахстан"),
        new Country("🇹🇷", "ТУРЦИЯ", "турция"),
        new Country("🇮🇱", "ИЗРАИЛЬ", "израиль"),
        new Country("🇦🇺", "АВСТРАЛИЯ", "австралия"),
        new Country("🇰🇷", "ЮЖНАЯ КОРЕЯ", "южная корея", "корея")
    );

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String username = intent == null ? "" : intent.getStringExtra("username");
        showOverlay();
        nextRound();
        connect(username);
        return START_NOT_STICKY;
    }

    private void showOverlay() {
        if (panel != null) return;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(10), dp(14), dp(10));
        panel.setBackgroundColor(0xEE10131A);

        TextView heading = makeText("УГАДАЙ ФЛАГ  •  FLAGLIVE", 16, 0xFFFFFFFF, true);
        panel.addView(heading);
        statusView = makeText("Подключение к TikTok LIVE…", 11, 0xFF55E6B0, false);
        panel.addView(statusView);
        flagView = makeText("🇳🇱", 54, Color.WHITE, true);
        flagView.setGravity(Gravity.CENTER);
        panel.addView(flagView);
        answerView = makeText("НАЗОВИ СТРАНУ В ЧАТЕ", 17, 0xFF55E6B0, true);
        answerView.setGravity(Gravity.CENTER);
        panel.addView(answerView);
        scoreView = makeText("🏆 Пока нет очков", 12, Color.WHITE, false);
        panel.addView(scoreView);

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                dp(310), -2,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        p.y = dp(70);
        panel.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float downX, downY;
            public boolean onTouch(android.view.View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX=p.x; startY=p.y; downX=e.getRawX(); downY=e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    p.x=startX+(int)(e.getRawX()-downX);
                    p.y=startY+(int)(e.getRawY()-downY);
                    windowManager.updateViewLayout(panel,p); return true;
                }
                return true;
            }
        });
        windowManager.addView(panel, p);
    }

    private void connect(String username) {
        try {
            TikTokLive.newClient(username)
                .onConnected((client, event) -> runOnUi(() -> statusView.setText("● LIVE подключён: @" + username)))
                .onDisconnected((client, event) -> runOnUi(() -> statusView.setText("Связь потеряна")))
                .onError((client, event) -> runOnUi(() -> statusView.setText("Ошибка подключения")))
                .onComment((client, event) -> {
                    String user = event.getUser().getName();
                    String message = event.getText();
                    checkAnswer(user, message);
                })
                .buildAndConnect();
        } catch (Exception e) {
            runOnUi(() -> statusView.setText("Не удалось подключиться"));
        }
    }

    private void checkAnswer(String user, String message) {
        if (roundIndex >= countries.size()) return;
        Country c = countries.get(roundIndex);
        String normalized = normalize(message);
        boolean correct = normalize(c.answer).equals(normalized);
        if (!correct) {
            for (String alias : c.aliases) if (normalize(alias).equals(normalized)) correct = true;
        }
        if (!correct) return;
        synchronized (winnersThisRound) {
            if (!winnersThisRound.add(user.toLowerCase(Locale.ROOT))) return;
            scores.put(user, scores.getOrDefault(user, 0) + 1);
        }
        runOnUi(() -> {
            answerView.setText("✓ " + user + " угадал!");
            updateScores();
            flagView.setText("🎉");
            flagView.postDelayed(this::nextRound, 2500);
        });
    }

    private void nextRound() {
        roundIndex = (roundIndex + 1) % countries.size();
        winnersThisRound.clear();
        Country c = countries.get(roundIndex);
        flagView.setText(c.flag);
        answerView.setText("НАЗОВИ СТРАНУ В ЧАТЕ");
        updateScores();
    }

    private void updateScores() {
        List<Map.Entry<String,Integer>> list = new ArrayList<>(scores.entrySet());
        list.sort((a,b) -> b.getValue() - a.getValue());
        StringBuilder s = new StringBuilder("🏆 ТОП: ");
        for (int i=0; i<Math.min(3,list.size()); i++) {
            if (i>0) s.append("  •  ");
            s.append(i+1).append(". ").append(list.get(i).getKey()).append(" ").append(list.get(i).getValue());
        }
        scoreView.setText(s.toString());
    }

    private String normalize(String s) {
        String n = Normalizer.normalize(s == null ? "" : s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        n = n.replaceAll("\\p{M}", "").replace('ё','е').trim();
        return n.replaceAll("[^a-zа-я0-9 ]", "").replaceAll("\\s+", " ");
    }

    private void runOnUi(Runnable r) {
        android.os.Handler h = new android.os.Handler(getMainLooper());
        h.post(r);
    }

    private TextView makeText(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    @Override public void onDestroy() {
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

# FlagLive 1.0

Android app prototype for a TikTok LIVE flag-guessing game.

## Features in this first prototype
- Enter a public TikTok LIVE username.
- Attempts to connect to the live chat using TikTokLiveJava.
- Floating movable overlay.
- Flag rounds, Russian answer aliases, one point per user per round, top-three score list.
- GitHub Actions workflow for building a debug APK.

## Important
The chat connector is an unofficial reverse-engineered community library, not an official TikTok API. TikTok can change its protocol or limit access, so connection reliability is not guaranteed. It is intended to read public LIVE comments only; it does not send messages or access private accounts.

## Build on your phone with GitHub Actions
1. Create a new GitHub repository named `FlagLive`.
2. Upload the contents of this ZIP to the repository root, including the hidden `.github` folder.
3. Open the **Actions** tab and enable workflows if GitHub asks.
4. Open **Build FlagLive APK** and press **Run workflow**.
5. When it finishes, open the run and download the `FlagLive-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`.

## Notes
- The first build may fail if the upstream JitPack dependency changes or is unavailable.
- This is an early prototype. Test the connection with a public LIVE before relying on it during a broadcast.
- No TikTok password, session cookie, or signing key is needed for this read-only public chat connection.
